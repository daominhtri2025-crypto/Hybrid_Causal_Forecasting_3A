<?php $__env->startSection('title', 'Toda-Yamamoto'); ?>
<?php $__env->startSection('page-title', 'Phase 3b — Toda-Yamamoto Cross-Check'); ?>
<?php $__env->startSection('page-subtitle', 'Granger vs Toda-Yamamoto agreement analysis'); ?>

<?php $__env->startSection('content'); ?>
<div id="ty-root">
    <div id="ty-loading">
        <div class="rounded-xl p-6 animate-pulse" style="background-color: var(--color-bg-card);">
            <div class="h-4 w-48 rounded mb-4" style="background-color: var(--color-border);"></div>
            <div class="h-32 rounded" style="background-color: var(--color-bg-input);"></div>
        </div>
    </div>
    <div id="ty-error" class="hidden"></div>
    <div id="ty-content" class="hidden space-y-6">
        <div id="ty-agreement" class="rounded-xl p-6 border" style="background-color: var(--color-bg-card); border-color: var(--color-border);"></div>
        <div class="rounded-xl border overflow-hidden" style="background-color: var(--color-bg-card); border-color: var(--color-border);">
            <div class="overflow-x-auto">
                <table class="w-full text-sm">
                    <thead>
                        <tr style="background-color: var(--color-bg-input);">
                            <th class="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider" style="color: var(--color-text-muted);">Pair</th>
                            <th class="px-4 py-3 text-center text-xs font-semibold uppercase tracking-wider" style="color: var(--color-text-muted);">Granger</th>
                            <th class="px-4 py-3 text-center text-xs font-semibold uppercase tracking-wider" style="color: var(--color-text-muted);">Toda-Yamamoto</th>
                            <th class="px-4 py-3 text-center text-xs font-semibold uppercase tracking-wider" style="color: var(--color-text-muted);">Agreement</th>
                        </tr>
                    </thead>
                    <tbody id="ty-tbody"></tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script type="module">
    async function load() {
        try {
            const data = await window.dashboardFetch('toda-yamamoto');
            document.getElementById('ty-loading').classList.add('hidden');
            document.getElementById('ty-content').classList.remove('hidden');
            render(data);
        } catch (err) {
            document.getElementById('ty-loading').classList.add('hidden');
            document.getElementById('ty-error').classList.remove('hidden');
            window.showError('ty-error', err.message);
        }
    }

    function sigBadge(val) {
        return val
            ? '<span class="inline-flex items-center rounded-full px-2 py-0.5 text-xs font-medium" style="background-color: rgba(59,130,246,0.15); color: var(--color-accent-blue);">Sig</span>'
            : '<span class="text-xs" style="color: var(--color-text-muted);">NS</span>';
    }

    function render(data) {
        const agr = data.agreement_pct;
        document.getElementById('ty-agreement').innerHTML = `
            <div class="flex items-center gap-4">
                <div class="text-3xl font-bold tabular-nums" style="color: var(--color-accent-blue);">${agr != null ? agr + '%' : '—'}</div>
                <div>
                    <p class="text-sm font-medium" style="color: var(--color-text-primary);">Granger–TY Agreement</p>
                    <p class="text-xs" style="color: var(--color-text-muted);">Percentage of pairs where both methods agree</p>
                </div>
            </div>
        `;

        const pairs = data.comparison ?? [];
        document.getElementById('ty-tbody').innerHTML = pairs.map(p => `
            <tr class="border-t" style="border-color: var(--color-border);">
                <td class="px-4 py-3 font-medium" style="color: var(--color-text-primary);">${p.cause} → ${p.effect}</td>
                <td class="px-4 py-3 text-center">${sigBadge(p.granger_significant)}</td>
                <td class="px-4 py-3 text-center">${sigBadge(p.ty_significant)}</td>
                <td class="px-4 py-3 text-center">
                    ${p.agree
                        ? '<span class="inline-flex items-center rounded-full px-2 py-0.5 text-xs font-medium" style="background-color: rgba(34,197,94,0.15); color: var(--color-kpi-positive);">Match</span>'
                        : '<span class="inline-flex items-center rounded-full px-2 py-0.5 text-xs font-medium" style="background-color: rgba(249,115,22,0.15); color: var(--color-accent-orange);">Mismatch</span>'}
                </td>
            </tr>
        `).join('');
    }

    load();
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/user/risk-dashboard/resources/views/dashboard/toda-yamamoto.blade.php ENDPATH**/ ?>