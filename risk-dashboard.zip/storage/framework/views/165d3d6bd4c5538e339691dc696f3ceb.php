<?php $__env->startSection('title', 'Cointegration'); ?>
<?php $__env->startSection('page-title', 'Phase 3 — Johansen Cointegration'); ?>
<?php $__env->startSection('page-subtitle', 'Cointegration rank determination and model route selection'); ?>

<?php $__env->startSection('content'); ?>
<div id="coint-root">
    <div id="coint-loading">
        <div class="rounded-xl p-6 animate-pulse" style="background-color: var(--color-bg-card);">
            <div class="h-4 w-48 rounded mb-4" style="background-color: var(--color-border);"></div>
            <div class="h-32 rounded" style="background-color: var(--color-bg-input);"></div>
        </div>
    </div>
    <div id="coint-error" class="hidden"></div>
    <div id="coint-content" class="hidden space-y-6">
        
        <div class="rounded-xl p-6 border" id="route-decision" style="background-color: var(--color-bg-card); border-color: var(--color-border);"></div>
        
        <div class="rounded-xl border overflow-hidden" style="background-color: var(--color-bg-card); border-color: var(--color-border);">
            <div class="overflow-x-auto">
                <table class="w-full text-sm">
                    <thead>
                        <tr style="background-color: var(--color-bg-input);">
                            <th class="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider" style="color: var(--color-text-muted);">H0: rank ≤ r</th>
                            <th class="px-4 py-3 text-right text-xs font-semibold uppercase tracking-wider" style="color: var(--color-text-muted);">Trace Stat</th>
                            <th class="px-4 py-3 text-right text-xs font-semibold uppercase tracking-wider" style="color: var(--color-text-muted);">Critical (5%)</th>
                            <th class="px-4 py-3 text-center text-xs font-semibold uppercase tracking-wider" style="color: var(--color-text-muted);">Decision</th>
                        </tr>
                    </thead>
                    <tbody id="coint-tbody"></tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script type="module">
    async function load() {
        try {
            const data = await window.dashboardFetch('cointegration');
            document.getElementById('coint-loading').classList.add('hidden');
            document.getElementById('coint-content').classList.remove('hidden');
            render(data);
        } catch (err) {
            document.getElementById('coint-loading').classList.add('hidden');
            document.getElementById('coint-error').classList.remove('hidden');
            window.showError('coint-error', err.message);
        }
    }

    function render(data) {
        const route = data.route ?? {};
        document.getElementById('route-decision').innerHTML = `
            <div class="flex items-start gap-4">
                <div class="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg"
                     style="background-color: rgba(59,130,246,0.15);">
                    <svg class="h-5 w-5" style="color: var(--color-accent-blue);" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"/>
                    </svg>
                </div>
                <div>
                    <h3 class="text-base font-semibold" style="color: var(--color-text-primary);">
                        Route: ${route.selected_route?.replace(/_/g, ' ') ?? '—'}
                    </h3>
                    <p class="mt-1 text-sm" style="color: var(--color-text-secondary);">
                        Cointegration rank r = ${route.rank ?? '—'} &middot; ${route.explanation ?? ''}
                    </p>
                </div>
            </div>
        `;

        const tests = data.rank_tests ?? [];
        document.getElementById('coint-tbody').innerHTML = tests.map(t => {
            const rejected = (t.trace_stat ?? 0) > (t.critical_value ?? Infinity);
            return `
                <tr class="border-t" style="border-color: var(--color-border);">
                    <td class="px-4 py-3 font-medium" style="color: var(--color-text-primary);">r ≤ ${t.r ?? '?'}</td>
                    <td class="px-4 py-3 text-right tabular-nums" style="color: var(--color-text-primary);">${t.trace_stat?.toFixed(3) ?? '—'}</td>
                    <td class="px-4 py-3 text-right tabular-nums" style="color: var(--color-text-secondary);">${t.critical_value?.toFixed(3) ?? '—'}</td>
                    <td class="px-4 py-3 text-center">
                        ${rejected
                            ? '<span class="inline-flex items-center rounded-full px-2 py-0.5 text-xs font-medium" style="background-color: rgba(239,68,68,0.15); color: var(--color-accent-red);">Reject</span>'
                            : '<span class="inline-flex items-center rounded-full px-2 py-0.5 text-xs font-medium" style="background-color: rgba(34,197,94,0.15); color: var(--color-kpi-positive);">Fail to Reject</span>'}
                    </td>
                </tr>
            `;
        }).join('');
    }

    load();
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/user/risk-dashboard/resources/views/dashboard/cointegration.blade.php ENDPATH**/ ?>